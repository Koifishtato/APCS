
public class Subscriber {
	private int subnum;
	 public Subscriber(int subnum){
		 this.subnum=subnum;
	 }
	 public Subscriber(){}
	 public void update()
	 {
	 }
	 public int getSubnum() {
		return subnum;
	}
	 public void setSubnum(int subnum) {
		this.subnum = subnum;
	}
}
