/**
 * Test class to test the CounterConsleMenu
 * @author Alexander Loeffler
 * @version 1.0
 */
public class CounterTest {

	public static void main(String[] args) {
		Counter a = new Counter();
		CounterConsoleMenu.openMenu(a);
	}

}
