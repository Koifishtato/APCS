
public class NullPointerExceptionThrown {

	public static void run() {
		String test = null;
		test.toCharArray();
		

	}

}
