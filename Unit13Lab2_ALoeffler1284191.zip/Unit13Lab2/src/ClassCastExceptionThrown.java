
public class ClassCastExceptionThrown {

	public static void run() {
			Object test = new Double(13);
			System.out.println((String)test);
	}

}
