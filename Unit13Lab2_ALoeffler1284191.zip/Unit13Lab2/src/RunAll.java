
public class RunAll {

	public static void main(String[] args) {
		ArrayIndexOutOfBoundsExceptionCatch.catchIt();
		ClassCastExceptionCatch.catchIt();
		IllegalArgumentExceptionCatch.catchIt();
		NullPointerExceptionCatch.catchit();
	}

}
