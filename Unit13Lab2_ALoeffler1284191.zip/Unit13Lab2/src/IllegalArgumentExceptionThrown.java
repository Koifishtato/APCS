
public class IllegalArgumentExceptionThrown {
	
	public static void run(){
		Integer test = new Integer(null);
	}
}
