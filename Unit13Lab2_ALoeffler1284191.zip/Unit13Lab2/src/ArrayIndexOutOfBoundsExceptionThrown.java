
public class ArrayIndexOutOfBoundsExceptionThrown {

	public static void run() {
		int [] test = {1,2,3,4,5};
			System.out.println(test[5]);
		
	}

}
