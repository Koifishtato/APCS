
public interface Resizable {
	public abstract void resizeObject(int x, int y);
	
}
