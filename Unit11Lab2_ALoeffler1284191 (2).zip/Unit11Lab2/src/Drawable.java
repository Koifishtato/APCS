
public interface Drawable {
	public abstract void drawObject();
}
