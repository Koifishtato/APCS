
public interface Rotatable {
	public abstract void rotateObject(int degree);
}
