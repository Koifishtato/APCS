
public interface Sounds {
	public abstract void playSound(String sound);
}
