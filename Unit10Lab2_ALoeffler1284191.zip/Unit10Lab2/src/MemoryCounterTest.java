/**
 * Test class to test the CounterConsleMenu
 * @author Alexander Loeffler
 * @version 1.0
 */
public class MemoryCounterTest {

	public static void main(String[] args) {
		Memcounter a = new Memcounter();
		CounterConsoleMenu.openMenu(a);
	}

}
