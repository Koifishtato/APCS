
public class DivideByZeroException  extends Exception{
	public DivideByZeroException(){
		
	}
}
