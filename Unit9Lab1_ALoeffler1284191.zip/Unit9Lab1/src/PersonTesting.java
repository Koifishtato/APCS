
public class PersonTesting {

	public static void main(String[] args) {
		Person A = new Person("Tony Baggadonuts","10/21/2001");
		System.out.println(A.getBDay());
		System.out.println(A.getName());
	}

}
